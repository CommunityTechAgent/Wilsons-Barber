import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function MerchandisePage() {
  const products = [
    {
      id: 1,
      name: "Wilson's Barbershop T-Shirt Green",
      priceRange: "$30.00 - $40.00",
      stock: "Low stock",
      image: "/placeholder.svg?height=200&width=200",
    },
  ]

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="mb-6">
        <Link
          href="/products"
          className="flex items-center gap-2 text-green-700 hover:text-green-800 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Products
        </Link>
      </div>

      <h1 className="text-4xl font-bold mb-2">Merchandise</h1>
      <p className="text-gray-500 mb-8">1 result</p>

      <h2 className="text-xl font-semibold mb-6">Featured</h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <div key={product.id} className="border rounded-lg overflow-hidden flex flex-col">
            <div className="relative">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={200}
                height={200}
                className="w-full h-48 object-cover"
              />
            </div>
            <div className="p-4 flex flex-col flex-grow">
              <h3 className="font-medium text-lg mb-2">{product.name}</h3>
              <div className="mt-auto">
                <div className="flex items-center gap-2">
                  <span className="font-bold">{product.priceRange}</span>
                </div>
                {product.stock && <p className="text-sm mt-1 text-amber-500">{product.stock}</p>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
