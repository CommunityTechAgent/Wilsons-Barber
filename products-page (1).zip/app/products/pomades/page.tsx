import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default function PomadesPage() {
  const products = [
    {
      id: 1,
      name: "DuitAll Pomade",
      price: 18.0,
      stock: "Out of stock",
      image: "/placeholder.svg?height=200&width=200",
    },
    {
      id: 2,
      name: "J.S. Sloane Beard Oil",
      price: 25.0,
      stock: "Low stock",
      image: "/images/js-sloane-beard-oil.png",
    },
    {
      id: 3,
      name: "Concrete Hold Matte Pomade",
      price: 11.0,
      stock: "Low stock",
      image: "/images/reuzel-pomade.png",
    },
    {
      id: 4,
      name: "Extreme Hold Matte Pomade",
      price: 11.0,
      stock: "Out of stock",
      image: "/images/extreme-hold-pomade.png",
    },
    {
      id: 5,
      name: "Fiber Pomade",
      price: 11.0,
      stock: "Out of stock",
      image: "/images/fiber-pomade.png",
    },
    {
      id: 6,
      name: "Green Pomade",
      price: 11.0,
      stock: "Low stock",
      image: "/images/green-pomade.png",
    },
    {
      id: 7,
      name: "Clay Pomade (Large)",
      price: 21.5,
      stock: "Low stock",
      image: "/images/clay-pomade.png",
    },
    {
      id: 8,
      name: "Green Pomade (Large)",
      price: 21.5,
      stock: "Low stock",
      image: "/images/green-pomade-large.png",
    },
    {
      id: 9,
      name: "Pink Pomade (Large)",
      price: 21.5,
      stock: "Low stock",
      image: "/images/pink-pomade.png",
    },
    {
      id: 10,
      name: "Matte Styling Paste",
      price: 16.5,
      stock: "",
      image: "/placeholder.svg?height=200&width=200",
    },
    {
      id: 11,
      name: "Baxters Shea Pomade",
      price: 24.0,
      originalPrice: 24.99,
      stock: "Out of stock",
      sale: true,
      image: "/images/baxter-shea-pomade.png",
    },
    {
      id: 12,
      name: "Baxter's Exfoliating Beard Oil",
      price: 28.99,
      stock: "Out of stock",
      image: "/placeholder.svg?height=200&width=200",
    },
  ]

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="mb-6">
        <Link
          href="/products"
          className="flex items-center gap-2 text-green-700 hover:text-green-800 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Products
        </Link>
      </div>

      <h1 className="text-4xl font-bold mb-8">Pomades</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <div key={product.id} className="border rounded-lg overflow-hidden flex flex-col">
            <div className="relative">
              <div className="w-full h-48 bg-gray-100 flex items-center justify-center">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  width={200}
                  height={200}
                  className="max-h-full max-w-full object-contain"
                />
              </div>
              {product.sale && <Badge className="absolute top-2 left-2 bg-rose-500">Sale</Badge>}
            </div>
            <div className="p-4 flex flex-col flex-grow">
              <h3 className="font-medium text-lg mb-2">{product.name}</h3>
              <div className="mt-auto">
                <div className="flex items-center gap-2">
                  {product.originalPrice ? (
                    <>
                      <span className="text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</span>
                      <span className="font-bold">${product.price.toFixed(2)}</span>
                    </>
                  ) : (
                    <span className="font-bold">${product.price.toFixed(2)}</span>
                  )}
                </div>
                {product.stock && (
                  <p
                    className={`text-sm mt-1 ${product.stock === "Out of stock" ? "text-rose-500" : "text-amber-500"}`}
                  >
                    {product.stock}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
