import Link from "next/link"
import Image from "next/image"
import { ArrowRight, ArrowLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function ProductsPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="mb-6">
        <Link href="/" className="flex items-center gap-2 text-green-700 hover:text-green-800 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>
      </div>

      <h1 className="text-4xl font-bold text-center mb-12">Products</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Pomades Section */}
        <Card className="flex flex-col h-full">
          <CardHeader>
            <CardTitle>Pomades</CardTitle>
          </CardHeader>
          <CardContent className="flex-grow">
            <div className="w-full h-48 bg-gray-100 rounded-md mb-4 flex items-center justify-center">
              <Image
                src="/images/baxter-shea-pomade.png"
                alt="Pomades"
                width={300}
                height={200}
                className="max-h-full max-w-full object-contain"
              />
            </div>
            <p className="text-muted-foreground">
              Explore our collection of premium pomades for every hair type and style.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/products/pomades" className="w-full">
              <Button variant="default" className="w-full group bg-green-700 hover:bg-green-800">
                See More
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        {/* Merchandise Section */}
        <Card className="flex flex-col h-full">
          <CardHeader>
            <CardTitle>Merchandise</CardTitle>
          </CardHeader>
          <CardContent className="flex-grow">
            <div className="w-full h-48 bg-gray-100 rounded-md mb-4 flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Merchandise"
                width={300}
                height={200}
                className="max-h-full max-w-full object-contain"
              />
            </div>
            <p className="text-muted-foreground">Check out our branded merchandise and accessories.</p>
          </CardContent>
          <CardFooter>
            <Link href="/products/merchandise" className="w-full">
              <Button variant="default" className="w-full group bg-green-700 hover:bg-green-800">
                See More
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        {/* Reuzel Products Section */}
        <Card className="flex flex-col h-full">
          <CardHeader>
            <CardTitle>Reuzel Products</CardTitle>
          </CardHeader>
          <CardContent className="flex-grow">
            <div className="w-full h-48 bg-gray-100 rounded-md mb-4 flex items-center justify-center">
              <Image
                src="/images/reuzel-tea-tree.png"
                alt="Reuzel Products"
                width={300}
                height={200}
                className="max-h-full max-w-full object-contain"
              />
            </div>
            <p className="text-muted-foreground">Discover the full range of Reuzel grooming products.</p>
          </CardContent>
          <CardFooter>
            <Link href="/products/reuzel" className="w-full">
              <Button variant="default" className="w-full group bg-green-700 hover:bg-green-800">
                See More
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        {/* Baxters of California Section */}
        <Card className="flex flex-col h-full">
          <CardHeader>
            <CardTitle>Baxters of California</CardTitle>
          </CardHeader>
          <CardContent className="flex-grow">
            <div className="w-full h-48 bg-gray-100 rounded-md mb-4 flex items-center justify-center">
              <Image
                src="/images/baxter-conditioner.png"
                alt="Baxters of California"
                width={300}
                height={200}
                className="max-h-full max-w-full object-contain"
              />
            </div>
            <p className="text-muted-foreground">Premium grooming products from Baxters of California.</p>
          </CardContent>
          <CardFooter>
            <Link href="/products/baxters" className="w-full">
              <Button variant="default" className="w-full group bg-green-700 hover:bg-green-800">
                See More
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
