import Link from "next/link"

interface BackButtonProps {
  href: string
  text: string
}

export default function BackButton({ href, text }: BackButtonProps) {
  return (
    <Link href={href}>
      <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded inline-flex items-center">
        <svg className="fill-current w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
          <path d="M7.05 9.29L6.34 10L1 14.34l.71.71L7.05 10.71 7.76 10l-1.42-1.42zM18.36 5.66L13 11h2v2h-2v2h2L18.36 7.76l.71-.71z" />
        </svg>
        {text}
      </button>
    </Link>
  )
}
